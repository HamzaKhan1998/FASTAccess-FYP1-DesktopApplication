﻿namespace FAST_Access
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateCoursesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateTeachersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateRoomsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.courseName = new System.Windows.Forms.TextBox();
            this.coursecomboBox5 = new System.Windows.Forms.ComboBox();
            this.coursecomboBox4 = new System.Windows.Forms.ComboBox();
            this.coursebox3 = new System.Windows.Forms.ComboBox();
            this.teacherName = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.coreElective = new System.Windows.Forms.ComboBox();
            this.classLab = new System.Windows.Forms.ComboBox();
            this.teacherID = new System.Windows.Forms.ComboBox();
            this.P3C1 = new System.Windows.Forms.ComboBox();
            this.P2C1 = new System.Windows.Forms.ComboBox();
            this.P1C1 = new System.Windows.Forms.ComboBox();
            this.P3C2 = new System.Windows.Forms.ComboBox();
            this.P2C2 = new System.Windows.Forms.ComboBox();
            this.P1C2 = new System.Windows.Forms.ComboBox();
            this.P3C3 = new System.Windows.Forms.ComboBox();
            this.P2C3 = new System.Windows.Forms.ComboBox();
            this.P1C3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.Section = new System.Windows.Forms.ComboBox();
            this.ViewTeachers = new ePOSOne.btnProduct.Button_WOC();
            this.AddTeacher = new ePOSOne.btnProduct.Button_WOC();
            this.RemoveTeacher = new ePOSOne.btnProduct.Button_WOC();
            this.ViewCourses = new ePOSOne.btnProduct.Button_WOC();
            this.AddCourse = new ePOSOne.btnProduct.Button_WOC();
            this.RemoveCourse = new ePOSOne.btnProduct.Button_WOC();
            this.ViewRooms = new ePOSOne.btnProduct.Button_WOC();
            this.AddRoom = new ePOSOne.btnProduct.Button_WOC();
            this.Remove = new ePOSOne.btnProduct.Button_WOC();
            this.buttonSubmit = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC4 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC5 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC1 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC3 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC2 = new ePOSOne.btnProduct.Button_WOC();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 57);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(324, 37);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 106);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.updateProfileToolStripMenuItem,
            this.updateCoursesToolStripMenuItem,
            this.updateTeachersToolStripMenuItem,
            this.updateRoomsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(900, 24);
            this.menuStrip1.TabIndex = 31;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // updateProfileToolStripMenuItem
            // 
            this.updateProfileToolStripMenuItem.Name = "updateProfileToolStripMenuItem";
            this.updateProfileToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.updateProfileToolStripMenuItem.Text = "Your Profile";
            this.updateProfileToolStripMenuItem.Click += new System.EventHandler(this.updateProfileToolStripMenuItem_Click);
            // 
            // updateCoursesToolStripMenuItem
            // 
            this.updateCoursesToolStripMenuItem.Name = "updateCoursesToolStripMenuItem";
            this.updateCoursesToolStripMenuItem.Size = new System.Drawing.Size(102, 20);
            this.updateCoursesToolStripMenuItem.Text = "Update Courses";
            this.updateCoursesToolStripMenuItem.Click += new System.EventHandler(this.updateCoursesToolStripMenuItem_Click);
            // 
            // updateTeachersToolStripMenuItem
            // 
            this.updateTeachersToolStripMenuItem.Name = "updateTeachersToolStripMenuItem";
            this.updateTeachersToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.updateTeachersToolStripMenuItem.Text = "Update Teachers";
            this.updateTeachersToolStripMenuItem.Click += new System.EventHandler(this.updateTeachersToolStripMenuItem_Click);
            // 
            // updateRoomsToolStripMenuItem
            // 
            this.updateRoomsToolStripMenuItem.Name = "updateRoomsToolStripMenuItem";
            this.updateRoomsToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.updateRoomsToolStripMenuItem.Text = "Update Rooms";
            this.updateRoomsToolStripMenuItem.Click += new System.EventHandler(this.updateRoomsToolStripMenuItem_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(488, 171);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(29, 33);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 32;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(488, 246);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(29, 33);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 33;
            this.pictureBox4.TabStop = false;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(240, 154);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(315, 26);
            this.textBox3.TabIndex = 43;
            this.textBox3.Text = "Change Username and Password";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(243, 199);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(24, 21);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 42;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.White;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(243, 242);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(24, 21);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 41;
            this.pictureBox6.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox2.Location = new System.Drawing.Point(273, 243);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(229, 20);
            this.textBox2.TabIndex = 40;
            this.textBox2.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox1.Location = new System.Drawing.Point(273, 199);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(229, 20);
            this.textBox1.TabIndex = 39;
            this.textBox1.Text = "User Name";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 379);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(95, 21);
            this.comboBox1.TabIndex = 59;
            this.comboBox1.Text = "Room Number";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox4.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox4.Location = new System.Drawing.Point(0, 324);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(95, 20);
            this.textBox4.TabIndex = 55;
            this.textBox4.Text = "Lab Name";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // courseName
            // 
            this.courseName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.courseName.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.courseName.Location = new System.Drawing.Point(0, 154);
            this.courseName.Name = "courseName";
            this.courseName.Size = new System.Drawing.Size(95, 20);
            this.courseName.TabIndex = 63;
            this.courseName.Text = "Course Name";
            // 
            // coursecomboBox5
            // 
            this.coursecomboBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.coursecomboBox5.FormattingEnabled = true;
            this.coursecomboBox5.Location = new System.Drawing.Point(101, 399);
            this.coursecomboBox5.Name = "coursecomboBox5";
            this.coursecomboBox5.Size = new System.Drawing.Size(95, 21);
            this.coursecomboBox5.TabIndex = 88;
            this.coursecomboBox5.Text = "Course 3";
            // 
            // coursecomboBox4
            // 
            this.coursecomboBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.coursecomboBox4.FormattingEnabled = true;
            this.coursecomboBox4.Location = new System.Drawing.Point(101, 372);
            this.coursecomboBox4.Name = "coursecomboBox4";
            this.coursecomboBox4.Size = new System.Drawing.Size(95, 21);
            this.coursecomboBox4.TabIndex = 86;
            this.coursecomboBox4.Text = "Course 2";
            // 
            // coursebox3
            // 
            this.coursebox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.coursebox3.FormattingEnabled = true;
            this.coursebox3.Location = new System.Drawing.Point(101, 345);
            this.coursebox3.Name = "coursebox3";
            this.coursebox3.Size = new System.Drawing.Size(95, 21);
            this.coursebox3.TabIndex = 84;
            this.coursebox3.Text = "Course 1";
            this.coursebox3.SelectedIndexChanged += new System.EventHandler(this.coursebox3_SelectedIndexChanged);
            // 
            // teacherName
            // 
            this.teacherName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.teacherName.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.teacherName.Location = new System.Drawing.Point(101, 319);
            this.teacherName.Name = "teacherName";
            this.teacherName.Size = new System.Drawing.Size(95, 20);
            this.teacherName.TabIndex = 75;
            this.teacherName.Text = "Teacher Name";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(580, 37);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(308, 407);
            this.dataGridView1.TabIndex = 95;
            // 
            // coreElective
            // 
            this.coreElective.BackColor = System.Drawing.Color.WhiteSmoke;
            this.coreElective.FormattingEnabled = true;
            this.coreElective.Location = new System.Drawing.Point(101, 153);
            this.coreElective.Name = "coreElective";
            this.coreElective.Size = new System.Drawing.Size(95, 21);
            this.coreElective.TabIndex = 96;
            this.coreElective.Text = "Core/Elective";
            // 
            // classLab
            // 
            this.classLab.BackColor = System.Drawing.Color.WhiteSmoke;
            this.classLab.FormattingEnabled = true;
            this.classLab.Location = new System.Drawing.Point(0, 299);
            this.classLab.Name = "classLab";
            this.classLab.Size = new System.Drawing.Size(95, 21);
            this.classLab.TabIndex = 99;
            this.classLab.Text = "Class/Lab";
            this.classLab.SelectedIndexChanged += new System.EventHandler(this.classLab_SelectedIndexChanged);
            // 
            // teacherID
            // 
            this.teacherID.BackColor = System.Drawing.Color.WhiteSmoke;
            this.teacherID.FormattingEnabled = true;
            this.teacherID.Location = new System.Drawing.Point(101, 234);
            this.teacherID.Name = "teacherID";
            this.teacherID.Size = new System.Drawing.Size(95, 21);
            this.teacherID.TabIndex = 100;
            this.teacherID.Text = "Teacher Name";
            this.teacherID.SelectedIndexChanged += new System.EventHandler(this.teacherID_SelectedIndexChanged);
            // 
            // P3C1
            // 
            this.P3C1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P3C1.FormattingEnabled = true;
            this.P3C1.Location = new System.Drawing.Point(404, 345);
            this.P3C1.Name = "P3C1";
            this.P3C1.Size = new System.Drawing.Size(170, 21);
            this.P3C1.TabIndex = 103;
            this.P3C1.Text = "Day";
            // 
            // P2C1
            // 
            this.P2C1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P2C1.FormattingEnabled = true;
            this.P2C1.Location = new System.Drawing.Point(303, 345);
            this.P2C1.Name = "P2C1";
            this.P2C1.Size = new System.Drawing.Size(95, 21);
            this.P2C1.TabIndex = 102;
            this.P2C1.Text = "Timing";
            // 
            // P1C1
            // 
            this.P1C1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P1C1.FormattingEnabled = true;
            this.P1C1.Location = new System.Drawing.Point(202, 345);
            this.P1C1.Name = "P1C1";
            this.P1C1.Size = new System.Drawing.Size(95, 21);
            this.P1C1.TabIndex = 101;
            this.P1C1.Text = "Duration";
            this.P1C1.SelectedIndexChanged += new System.EventHandler(this.P1C1_SelectedIndexChanged);
            // 
            // P3C2
            // 
            this.P3C2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P3C2.FormattingEnabled = true;
            this.P3C2.Location = new System.Drawing.Point(404, 372);
            this.P3C2.Name = "P3C2";
            this.P3C2.Size = new System.Drawing.Size(170, 21);
            this.P3C2.TabIndex = 106;
            this.P3C2.Text = "Day";
            // 
            // P2C2
            // 
            this.P2C2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P2C2.FormattingEnabled = true;
            this.P2C2.Location = new System.Drawing.Point(303, 372);
            this.P2C2.Name = "P2C2";
            this.P2C2.Size = new System.Drawing.Size(95, 21);
            this.P2C2.TabIndex = 105;
            this.P2C2.Text = "Timing";
            // 
            // P1C2
            // 
            this.P1C2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P1C2.FormattingEnabled = true;
            this.P1C2.Location = new System.Drawing.Point(202, 372);
            this.P1C2.Name = "P1C2";
            this.P1C2.Size = new System.Drawing.Size(95, 21);
            this.P1C2.TabIndex = 104;
            this.P1C2.Text = "Duration";
            this.P1C2.SelectedIndexChanged += new System.EventHandler(this.P1C2_SelectedIndexChanged);
            // 
            // P3C3
            // 
            this.P3C3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P3C3.FormattingEnabled = true;
            this.P3C3.Location = new System.Drawing.Point(404, 399);
            this.P3C3.Name = "P3C3";
            this.P3C3.Size = new System.Drawing.Size(170, 21);
            this.P3C3.TabIndex = 109;
            this.P3C3.Text = "Day";
            // 
            // P2C3
            // 
            this.P2C3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P2C3.FormattingEnabled = true;
            this.P2C3.Location = new System.Drawing.Point(303, 399);
            this.P2C3.Name = "P2C3";
            this.P2C3.Size = new System.Drawing.Size(95, 21);
            this.P2C3.TabIndex = 108;
            this.P2C3.Text = "Timing";
            // 
            // P1C3
            // 
            this.P1C3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.P1C3.FormattingEnabled = true;
            this.P1C3.Location = new System.Drawing.Point(202, 399);
            this.P1C3.Name = "P1C3";
            this.P1C3.Size = new System.Drawing.Size(95, 21);
            this.P1C3.TabIndex = 107;
            this.P1C3.Text = "Duration";
            this.P1C3.SelectedIndexChanged += new System.EventHandler(this.P1C3_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(101, 206);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(95, 21);
            this.comboBox2.TabIndex = 110;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // Section
            // 
            this.Section.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Section.FormattingEnabled = true;
            this.Section.Location = new System.Drawing.Point(202, 153);
            this.Section.Name = "Section";
            this.Section.Size = new System.Drawing.Size(95, 21);
            this.Section.TabIndex = 111;
            this.Section.Text = "Section";
            this.Section.SelectedIndexChanged += new System.EventHandler(this.Section_SelectedIndexChanged);
            // 
            // ViewTeachers
            // 
            this.ViewTeachers.BorderColor = System.Drawing.Color.RoyalBlue;
            this.ViewTeachers.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.ViewTeachers.FlatAppearance.BorderSize = 0;
            this.ViewTeachers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewTeachers.ForeColor = System.Drawing.Color.Coral;
            this.ViewTeachers.Location = new System.Drawing.Point(101, 290);
            this.ViewTeachers.Name = "ViewTeachers";
            this.ViewTeachers.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.ViewTeachers.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.ViewTeachers.OnHoverTextColor = System.Drawing.Color.Black;
            this.ViewTeachers.Size = new System.Drawing.Size(95, 23);
            this.ViewTeachers.TabIndex = 78;
            this.ViewTeachers.Text = "View All";
            this.ViewTeachers.TextColor = System.Drawing.Color.White;
            this.ViewTeachers.UseVisualStyleBackColor = true;
            this.ViewTeachers.Click += new System.EventHandler(this.ViewTeachers_Click);
            // 
            // AddTeacher
            // 
            this.AddTeacher.BorderColor = System.Drawing.Color.RoyalBlue;
            this.AddTeacher.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.AddTeacher.FlatAppearance.BorderSize = 0;
            this.AddTeacher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddTeacher.ForeColor = System.Drawing.Color.Coral;
            this.AddTeacher.Location = new System.Drawing.Point(101, 426);
            this.AddTeacher.Name = "AddTeacher";
            this.AddTeacher.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.AddTeacher.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.AddTeacher.OnHoverTextColor = System.Drawing.Color.Black;
            this.AddTeacher.Size = new System.Drawing.Size(95, 23);
            this.AddTeacher.TabIndex = 77;
            this.AddTeacher.Text = "Add Teacher";
            this.AddTeacher.TextColor = System.Drawing.Color.White;
            this.AddTeacher.UseVisualStyleBackColor = true;
            this.AddTeacher.Click += new System.EventHandler(this.AddTeacher_Click);
            // 
            // RemoveTeacher
            // 
            this.RemoveTeacher.BorderColor = System.Drawing.Color.RoyalBlue;
            this.RemoveTeacher.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.RemoveTeacher.FlatAppearance.BorderSize = 0;
            this.RemoveTeacher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemoveTeacher.ForeColor = System.Drawing.Color.Coral;
            this.RemoveTeacher.Location = new System.Drawing.Point(101, 261);
            this.RemoveTeacher.Name = "RemoveTeacher";
            this.RemoveTeacher.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.RemoveTeacher.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.RemoveTeacher.OnHoverTextColor = System.Drawing.Color.Black;
            this.RemoveTeacher.Size = new System.Drawing.Size(95, 23);
            this.RemoveTeacher.TabIndex = 76;
            this.RemoveTeacher.Text = "Remove Teacher";
            this.RemoveTeacher.TextColor = System.Drawing.Color.White;
            this.RemoveTeacher.UseVisualStyleBackColor = true;
            this.RemoveTeacher.Click += new System.EventHandler(this.RemoveTeacher_Click);
            // 
            // ViewCourses
            // 
            this.ViewCourses.BorderColor = System.Drawing.Color.RoyalBlue;
            this.ViewCourses.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.ViewCourses.FlatAppearance.BorderSize = 0;
            this.ViewCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewCourses.ForeColor = System.Drawing.Color.Coral;
            this.ViewCourses.Location = new System.Drawing.Point(0, 225);
            this.ViewCourses.Name = "ViewCourses";
            this.ViewCourses.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.ViewCourses.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.ViewCourses.OnHoverTextColor = System.Drawing.Color.Black;
            this.ViewCourses.Size = new System.Drawing.Size(95, 23);
            this.ViewCourses.TabIndex = 66;
            this.ViewCourses.Text = "View All";
            this.ViewCourses.TextColor = System.Drawing.Color.White;
            this.ViewCourses.UseVisualStyleBackColor = true;
            this.ViewCourses.Click += new System.EventHandler(this.ViewCourses_Click);
            // 
            // AddCourse
            // 
            this.AddCourse.BorderColor = System.Drawing.Color.RoyalBlue;
            this.AddCourse.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.AddCourse.FlatAppearance.BorderSize = 0;
            this.AddCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddCourse.ForeColor = System.Drawing.Color.Coral;
            this.AddCourse.Location = new System.Drawing.Point(0, 180);
            this.AddCourse.Name = "AddCourse";
            this.AddCourse.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.AddCourse.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.AddCourse.OnHoverTextColor = System.Drawing.Color.Black;
            this.AddCourse.Size = new System.Drawing.Size(95, 23);
            this.AddCourse.TabIndex = 65;
            this.AddCourse.Text = "Add Course";
            this.AddCourse.TextColor = System.Drawing.Color.White;
            this.AddCourse.UseVisualStyleBackColor = true;
            this.AddCourse.Click += new System.EventHandler(this.AddCourse_Click);
            // 
            // RemoveCourse
            // 
            this.RemoveCourse.BorderColor = System.Drawing.Color.RoyalBlue;
            this.RemoveCourse.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.RemoveCourse.FlatAppearance.BorderSize = 0;
            this.RemoveCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemoveCourse.ForeColor = System.Drawing.Color.Coral;
            this.RemoveCourse.Location = new System.Drawing.Point(0, 204);
            this.RemoveCourse.Name = "RemoveCourse";
            this.RemoveCourse.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.RemoveCourse.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.RemoveCourse.OnHoverTextColor = System.Drawing.Color.Black;
            this.RemoveCourse.Size = new System.Drawing.Size(95, 23);
            this.RemoveCourse.TabIndex = 64;
            this.RemoveCourse.Text = "Remove Course";
            this.RemoveCourse.TextColor = System.Drawing.Color.White;
            this.RemoveCourse.UseVisualStyleBackColor = true;
            this.RemoveCourse.Click += new System.EventHandler(this.RemoveCourse_Click);
            // 
            // ViewRooms
            // 
            this.ViewRooms.BorderColor = System.Drawing.Color.RoyalBlue;
            this.ViewRooms.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.ViewRooms.FlatAppearance.BorderSize = 0;
            this.ViewRooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewRooms.ForeColor = System.Drawing.Color.Coral;
            this.ViewRooms.Location = new System.Drawing.Point(0, 426);
            this.ViewRooms.Name = "ViewRooms";
            this.ViewRooms.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.ViewRooms.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.ViewRooms.OnHoverTextColor = System.Drawing.Color.Black;
            this.ViewRooms.Size = new System.Drawing.Size(95, 23);
            this.ViewRooms.TabIndex = 58;
            this.ViewRooms.Text = "View All";
            this.ViewRooms.TextColor = System.Drawing.Color.White;
            this.ViewRooms.UseVisualStyleBackColor = true;
            this.ViewRooms.Click += new System.EventHandler(this.ViewRooms_Click);
            // 
            // AddRoom
            // 
            this.AddRoom.BorderColor = System.Drawing.Color.RoyalBlue;
            this.AddRoom.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.AddRoom.FlatAppearance.BorderSize = 0;
            this.AddRoom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddRoom.ForeColor = System.Drawing.Color.Coral;
            this.AddRoom.Location = new System.Drawing.Point(0, 350);
            this.AddRoom.Name = "AddRoom";
            this.AddRoom.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.AddRoom.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.AddRoom.OnHoverTextColor = System.Drawing.Color.Black;
            this.AddRoom.Size = new System.Drawing.Size(95, 23);
            this.AddRoom.TabIndex = 57;
            this.AddRoom.Text = "Add Room";
            this.AddRoom.TextColor = System.Drawing.Color.White;
            this.AddRoom.UseVisualStyleBackColor = true;
            this.AddRoom.Click += new System.EventHandler(this.AddRoom_Click);
            // 
            // Remove
            // 
            this.Remove.BorderColor = System.Drawing.Color.RoyalBlue;
            this.Remove.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.Remove.FlatAppearance.BorderSize = 0;
            this.Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Remove.ForeColor = System.Drawing.Color.Coral;
            this.Remove.Location = new System.Drawing.Point(0, 406);
            this.Remove.Name = "Remove";
            this.Remove.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.Remove.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.Remove.OnHoverTextColor = System.Drawing.Color.Black;
            this.Remove.Size = new System.Drawing.Size(95, 23);
            this.Remove.TabIndex = 56;
            this.Remove.Text = "Remove Room";
            this.Remove.TextColor = System.Drawing.Color.White;
            this.Remove.UseVisualStyleBackColor = true;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.BorderColor = System.Drawing.Color.RoyalBlue;
            this.buttonSubmit.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.buttonSubmit.FlatAppearance.BorderSize = 0;
            this.buttonSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSubmit.ForeColor = System.Drawing.Color.Coral;
            this.buttonSubmit.Location = new System.Drawing.Point(345, 279);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.buttonSubmit.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.buttonSubmit.OnHoverTextColor = System.Drawing.Color.Black;
            this.buttonSubmit.Size = new System.Drawing.Size(75, 23);
            this.buttonSubmit.TabIndex = 44;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.TextColor = System.Drawing.Color.White;
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // button_WOC4
            // 
            this.button_WOC4.BorderColor = System.Drawing.Color.Turquoise;
            this.button_WOC4.ButtonColor = System.Drawing.Color.Turquoise;
            this.button_WOC4.FlatAppearance.BorderSize = 0;
            this.button_WOC4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC4.Location = new System.Drawing.Point(310, 244);
            this.button_WOC4.Name = "button_WOC4";
            this.button_WOC4.OnHoverBorderColor = System.Drawing.Color.MediumTurquoise;
            this.button_WOC4.OnHoverButtonColor = System.Drawing.Color.DeepSkyBlue;
            this.button_WOC4.OnHoverTextColor = System.Drawing.Color.Black;
            this.button_WOC4.Size = new System.Drawing.Size(172, 35);
            this.button_WOC4.TabIndex = 28;
            this.button_WOC4.Text = "Get Teacher Information File";
            this.button_WOC4.TextColor = System.Drawing.Color.Black;
            this.button_WOC4.UseVisualStyleBackColor = true;
            this.button_WOC4.Click += new System.EventHandler(this.button_WOC4_Click_1);
            // 
            // button_WOC5
            // 
            this.button_WOC5.BorderColor = System.Drawing.Color.Turquoise;
            this.button_WOC5.ButtonColor = System.Drawing.Color.Turquoise;
            this.button_WOC5.FlatAppearance.BorderSize = 0;
            this.button_WOC5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC5.Location = new System.Drawing.Point(310, 171);
            this.button_WOC5.Name = "button_WOC5";
            this.button_WOC5.OnHoverBorderColor = System.Drawing.Color.MediumTurquoise;
            this.button_WOC5.OnHoverButtonColor = System.Drawing.Color.DeepSkyBlue;
            this.button_WOC5.OnHoverTextColor = System.Drawing.Color.Black;
            this.button_WOC5.Size = new System.Drawing.Size(172, 35);
            this.button_WOC5.TabIndex = 27;
            this.button_WOC5.Text = "Get Course Information File";
            this.button_WOC5.TextColor = System.Drawing.Color.Black;
            this.button_WOC5.UseVisualStyleBackColor = true;
            this.button_WOC5.Click += new System.EventHandler(this.button_WOC5_Click_1);
            // 
            // button_WOC1
            // 
            this.button_WOC1.BorderColor = System.Drawing.Color.RoyalBlue;
            this.button_WOC1.ButtonColor = System.Drawing.Color.RoyalBlue;
            this.button_WOC1.FlatAppearance.BorderSize = 0;
            this.button_WOC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC1.Location = new System.Drawing.Point(281, 304);
            this.button_WOC1.Name = "button_WOC1";
            this.button_WOC1.OnHoverBorderColor = System.Drawing.Color.Aqua;
            this.button_WOC1.OnHoverButtonColor = System.Drawing.Color.Aqua;
            this.button_WOC1.OnHoverTextColor = System.Drawing.Color.Black;
            this.button_WOC1.Size = new System.Drawing.Size(236, 35);
            this.button_WOC1.TabIndex = 26;
            this.button_WOC1.Text = "Generate Time Table";
            this.button_WOC1.TextColor = System.Drawing.Color.White;
            this.button_WOC1.UseVisualStyleBackColor = true;
            this.button_WOC1.Click += new System.EventHandler(this.button_WOC1_Click_1);
            // 
            // button_WOC3
            // 
            this.button_WOC3.BorderColor = System.Drawing.Color.White;
            this.button_WOC3.ButtonColor = System.Drawing.Color.White;
            this.button_WOC3.FlatAppearance.BorderSize = 0;
            this.button_WOC3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC3.ForeColor = System.Drawing.Color.Coral;
            this.button_WOC3.Location = new System.Drawing.Point(778, -12);
            this.button_WOC3.Name = "button_WOC3";
            this.button_WOC3.OnHoverBorderColor = System.Drawing.Color.LawnGreen;
            this.button_WOC3.OnHoverButtonColor = System.Drawing.Color.LawnGreen;
            this.button_WOC3.OnHoverTextColor = System.Drawing.Color.White;
            this.button_WOC3.Size = new System.Drawing.Size(27, 36);
            this.button_WOC3.TabIndex = 9;
            this.button_WOC3.Text = "_";
            this.button_WOC3.TextColor = System.Drawing.Color.DarkGray;
            this.button_WOC3.UseVisualStyleBackColor = true;
            this.button_WOC3.Click += new System.EventHandler(this.button_WOC3_Click);
            // 
            // button_WOC2
            // 
            this.button_WOC2.BorderColor = System.Drawing.Color.White;
            this.button_WOC2.ButtonColor = System.Drawing.Color.White;
            this.button_WOC2.FlatAppearance.BorderSize = 0;
            this.button_WOC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC2.ForeColor = System.Drawing.Color.Coral;
            this.button_WOC2.Image = ((System.Drawing.Image)(resources.GetObject("button_WOC2.Image")));
            this.button_WOC2.Location = new System.Drawing.Point(802, -6);
            this.button_WOC2.Name = "button_WOC2";
            this.button_WOC2.OnHoverBorderColor = System.Drawing.Color.RoyalBlue;
            this.button_WOC2.OnHoverButtonColor = System.Drawing.Color.RoyalBlue;
            this.button_WOC2.OnHoverTextColor = System.Drawing.Color.White;
            this.button_WOC2.Size = new System.Drawing.Size(110, 30);
            this.button_WOC2.TabIndex = 8;
            this.button_WOC2.Text = "Log Out";
            this.button_WOC2.TextColor = System.Drawing.Color.RoyalBlue;
            this.button_WOC2.UseVisualStyleBackColor = true;
            this.button_WOC2.Click += new System.EventHandler(this.button_WOC2_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(900, 456);
            this.Controls.Add(this.Section);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.P3C3);
            this.Controls.Add(this.P2C3);
            this.Controls.Add(this.P1C3);
            this.Controls.Add(this.P3C2);
            this.Controls.Add(this.P2C2);
            this.Controls.Add(this.P1C2);
            this.Controls.Add(this.P3C1);
            this.Controls.Add(this.P2C1);
            this.Controls.Add(this.P1C1);
            this.Controls.Add(this.teacherID);
            this.Controls.Add(this.classLab);
            this.Controls.Add(this.coreElective);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.coursecomboBox5);
            this.Controls.Add(this.coursecomboBox4);
            this.Controls.Add(this.coursebox3);
            this.Controls.Add(this.ViewTeachers);
            this.Controls.Add(this.AddTeacher);
            this.Controls.Add(this.RemoveTeacher);
            this.Controls.Add(this.teacherName);
            this.Controls.Add(this.ViewCourses);
            this.Controls.Add(this.AddCourse);
            this.Controls.Add(this.RemoveCourse);
            this.Controls.Add(this.courseName);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.ViewRooms);
            this.Controls.Add(this.AddRoom);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.button_WOC4);
            this.Controls.Add(this.button_WOC5);
            this.Controls.Add(this.button_WOC1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_WOC3);
            this.Controls.Add(this.button_WOC2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form3";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private ePOSOne.btnProduct.Button_WOC button_WOC3;
        private ePOSOne.btnProduct.Button_WOC button_WOC2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private ePOSOne.btnProduct.Button_WOC button_WOC4;
        private ePOSOne.btnProduct.Button_WOC button_WOC5;
        private ePOSOne.btnProduct.Button_WOC button_WOC1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateCoursesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateTeachersToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private ePOSOne.btnProduct.Button_WOC buttonSubmit;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem updateRoomsToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox1;
        private ePOSOne.btnProduct.Button_WOC ViewRooms;
        private ePOSOne.btnProduct.Button_WOC AddRoom;
        private ePOSOne.btnProduct.Button_WOC Remove;
        private System.Windows.Forms.TextBox textBox4;
        private ePOSOne.btnProduct.Button_WOC ViewCourses;
        private ePOSOne.btnProduct.Button_WOC AddCourse;
        private ePOSOne.btnProduct.Button_WOC RemoveCourse;
        private System.Windows.Forms.TextBox courseName;
        private System.Windows.Forms.ComboBox coursecomboBox5;
        private System.Windows.Forms.ComboBox coursecomboBox4;
        private System.Windows.Forms.ComboBox coursebox3;
        private ePOSOne.btnProduct.Button_WOC ViewTeachers;
        private ePOSOne.btnProduct.Button_WOC AddTeacher;
        private ePOSOne.btnProduct.Button_WOC RemoveTeacher;
        private System.Windows.Forms.TextBox teacherName;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox coreElective;
        private System.Windows.Forms.ComboBox classLab;
        private System.Windows.Forms.ComboBox teacherID;
        private System.Windows.Forms.ComboBox P3C1;
        private System.Windows.Forms.ComboBox P2C1;
        private System.Windows.Forms.ComboBox P1C1;
        private System.Windows.Forms.ComboBox P3C2;
        private System.Windows.Forms.ComboBox P2C2;
        private System.Windows.Forms.ComboBox P1C2;
        private System.Windows.Forms.ComboBox P3C3;
        private System.Windows.Forms.ComboBox P2C3;
        private System.Windows.Forms.ComboBox P1C3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox Section;
    }
}