﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using IronPython.Hosting;
using IronPython.SQLite;
using Microsoft.Scripting;
using Microsoft.Scripting.Hosting;
using System.Data.SQLite;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace FAST_Access
{

    public partial class Form3 : Form
    {
        int rn = 312;
        bool enable_button = new bool();
        bool enable_button1 = new bool();
        Form2 originalForm = new Form2();
        public Form3(Form2 incomingForm)
        {
            Python.CreateEngine();
            originalForm = incomingForm;
            InitializeComponent();
            this.button_WOC1.Enabled = false;
            button_WOC1.ButtonColor = Color.Gray;
            button_WOC1.BorderColor = Color.Gray;
            this.pictureBox3.Hide();
            this.pictureBox4.Hide();
            this.hideYourProfile();
            this.hideRooms();
            this.hideCourses();
            this.hideTeachers();
            FillCombobox();
            fillCoreElective();
            fillCourseLab();
            FillCombobox2();
//            FillCombobox1();
            fillDays();
            fillCourses();
            FillSection();
            //   fillCourseLab();
            this.textBox4.Enabled = false;
            this.textBox4.BackColor = Color.DarkGray;

         

        }

        private SQLiteConnection sqlcon;
        private SQLiteCommand sqlcmd;
        private SQLiteDataAdapter DB;
        private SQLiteDataAdapter DB1;
        private SQLiteDataAdapter DB2;
        private SQLiteDataAdapter DB3;
        private DataSet DS = new DataSet();
        private DataSet DS1 = new DataSet();
        private DataSet DS2 = new DataSet();
        private DataSet DS3 = new DataSet();
        private DataTable DT = new DataTable();
        private DataTable DT1 = new DataTable();
        private DataTable DT2 = new DataTable();

        public void SetConnection()
        {
            sqlcon = new SQLiteConnection("Data Source = class_schedule_4.db");
        }

        public void ExecuteQuery(string txtQuery)
        {
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            sqlcmd.CommandText = txtQuery;
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();

        }

        public void FillSection()
        {
            this.Section.Items.Add("1-A");
            this.Section.Items.Add("1-B");
            this.Section.Items.Add("1-C");
            this.Section.Items.Add("1-D");
            this.Section.Items.Add("1-E");
            this.Section.Items.Add("1-F");

            this.Section.Items.Add("2-A");
            this.Section.Items.Add("2-B");
            this.Section.Items.Add("2-C");
            this.Section.Items.Add("2-D");
            this.Section.Items.Add("2-E");
            this.Section.Items.Add("2-F");

            this.Section.Items.Add("3-A");
            this.Section.Items.Add("3-B");
            this.Section.Items.Add("3-C");
            this.Section.Items.Add("3-D");
            this.Section.Items.Add("3-E");
            this.Section.Items.Add("3-F");

            this.Section.Items.Add("4-A");
            this.Section.Items.Add("4-B");
            this.Section.Items.Add("4-C");
            this.Section.Items.Add("4-D");
            this.Section.Items.Add("4-E");
            this.Section.Items.Add("4-F");
        }

        protected void FillCombobox()
        {
            sqlcon = new SQLiteConnection
            ("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select RNumber from room";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            comboBox1.DisplayMember = "RNumber";
            comboBox1.ValueMember = "RNumber";
            comboBox1.DataSource = DS.Tables[0];
            sqlcon.Close();

        }

        protected void FillCombobox2()
        {
            sqlcon = new SQLiteConnection
            ("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select CourseName from course";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            comboBox2.DisplayMember = "CourseName";
            comboBox2.ValueMember = "CourseName";
            comboBox2.DataSource = DS.Tables[0];
            sqlcon.Close();

        }

        protected void FillCombobox1()
        {
            sqlcon = new SQLiteConnection
            ("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select Name from instructor";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            teacherID.DataSource = DS.Tables[0];
            teacherID.BindingContext = new BindingContext();
            teacherID.DisplayMember = "Name";
            teacherID.ValueMember = "Name";

            sqlcon.Close();


        } 

        public void fillCourseLab()
        {
            this.classLab.Items.Add("Class");
            this.classLab.Items.Add("Lab");
        }
        public void fillCoreElective()
        {
            this.coreElective.Items.Add("Core");
            this.coreElective.Items.Add("Elective");
            this.coreElective.Items.Add("Core Lab");
            this.coreElective.Items.Add("Elective Lab");

        }
        public void fillDays()
        {

            //1hourx3
            this.P3C2.Items.Add("Monday,Wednesday,Friday");//1
            this.P3C2.Items.Add("Monday,Thursday,Friday");//5
            this.P3C2.Items.Add("Tuesday,Wednesday,Thursday");//2
            this.P3C2.Items.Add("Wednesday,Thursday,Friday");//3
            this.P3C2.Items.Add("Tuesday,Thursday,Friday");//4
            //1.5x2
            this.P3C2.Items.Add("Monday,Tuesday");//1
            this.P3C2.Items.Add("Wednesday,Thursday");//5
            this.P3C2.Items.Add("Tuesday,Wednesday");//2
            this.P3C2.Items.Add("Monday,Friday");//4
            this.P3C2.Items.Add("Tuesday,Thursday");//3

            //3x1
            this.P3C2.Items.Add("Monday");
            this.P3C2.Items.Add("Tuesday");
            this.P3C2.Items.Add("Wednesday");
            this.P3C2.Items.Add("Thursday");
            this.P3C2.Items.Add("Friday");

            //1hourx3
            this.P3C3.Items.Add("Monday,Wednesday,Friday");//1
            this.P3C3.Items.Add("Monday,Thursday,Friday");//5
            this.P3C3.Items.Add("Tuesday,Wednesday,Thursday");//2
            this.P3C3.Items.Add("Wednesday,Thursday,Friday");//3
            this.P3C3.Items.Add("Tuesday,Thursday,Friday");//4
            //1.5x2
            this.P3C3.Items.Add("Monday,Tuesday");//1
            this.P3C3.Items.Add("Wednesday,Thursday");//5
            this.P3C3.Items.Add("Tuesday,Wednesday");//2
            this.P3C3.Items.Add("Monday,Friday");//4
            this.P3C3.Items.Add("Tuesday,Thursday");//3

            //3x1
            this.P3C3.Items.Add("Monday");
            this.P3C3.Items.Add("Tuesday");
            this.P3C3.Items.Add("Wednesday");
            this.P3C3.Items.Add("Thursday");
            this.P3C3.Items.Add("Friday");

            this.P1C1.Items.Add("3hr x 1 class");
            this.P1C1.Items.Add("2hr x 1 class");
            this.P1C1.Items.Add("1.5hr x 2 class");
            this.P1C1.Items.Add("1hr x 3 class");

            this.P1C2.Items.Add("3hr x 1 class");
            this.P1C2.Items.Add("2hr x 1 class");
            this.P1C2.Items.Add("1.5hr x 2 class");
            this.P1C2.Items.Add("1hr x 3 class");

            this.P1C2.Items.Add("3hr x 1 class");
            this.P1C2.Items.Add("2hr x 1 class");
            this.P1C2.Items.Add("1.5hr x 2 class");
            this.P1C2.Items.Add("1hr x 3 class");

            this.P2C1.Items.Add("First Half");
            this.P2C1.Items.Add("Second Half");

            this.P2C2.Items.Add("First Half");
            this.P2C2.Items.Add("Second Half");

            this.P2C3.Items.Add("First Half");
            this.P2C3.Items.Add("Second Half");
            


        }
        public void fillCourses()
        {
            sqlcon = new SQLiteConnection("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select CourseName from course";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            coursebox3.DataSource = DS.Tables[0];
            coursebox3.BindingContext = new BindingContext();
            coursebox3.DisplayMember = "CourseName";
            coursebox3.ValueMember = "CourseName";

            coursecomboBox4.DataSource = DS.Tables[0];
            coursecomboBox4.BindingContext = new BindingContext();
            coursecomboBox4.DisplayMember = "CourseName";
            coursecomboBox4.ValueMember = "CourseName";

            coursecomboBox5.DataSource = DS.Tables[0];
            coursecomboBox5.BindingContext = new BindingContext();
            coursecomboBox5.DisplayMember = "CourseName";
            coursecomboBox5.ValueMember = "CourseName";

            string CommandText2 = "select Name from instructor";
            DB2 = new SQLiteDataAdapter(CommandText2, sqlcon);
            DS2.Reset();
            DB2.Fill(DS2);

            teacherID.DataSource = DS2.Tables[0];
            teacherID.BindingContext = new BindingContext();
            teacherID.DisplayMember = "Name";
            teacherID.ValueMember = "Name";

            sqlcon.Close();

        }
        public void fillCourses1()
        {
            sqlcon = new SQLiteConnection("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select CourseName from course";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            coursebox3.DataSource = DS.Tables[0];
            coursebox3.BindingContext = new BindingContext();
            coursebox3.DisplayMember = "CourseName";
            coursebox3.ValueMember = "CourseName";
            sqlcon.Close();

        }
        public void fillCourses2()
        {
            sqlcon = new SQLiteConnection("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select CourseName from course";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            coursecomboBox4.DataSource = DS.Tables[0];
            coursecomboBox4.BindingContext = new BindingContext();
            coursecomboBox4.DisplayMember = "CourseName";
            coursecomboBox4.ValueMember = "CourseName";

            sqlcon.Close();
        }
        public void fillCourses3()
        {
            sqlcon = new SQLiteConnection("Data Source=class_schedule_4.db;Version=3;new=False;Compress=True;");

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select CourseName from course";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            coursecomboBox5.DataSource = DS.Tables[0];
            coursecomboBox5.BindingContext = new BindingContext();
            coursecomboBox5.DisplayMember = "CourseName";
            coursecomboBox5.ValueMember = "CourseName";
            sqlcon.Close();

        }
        private void loaddata()
        {
            
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }
        private void button_WOC1_Click(object sender, EventArgs e)
        {

            if (button_WOC1.Enabled==true)
            {
                ScriptEngine engine = Python.CreateEngine();
                engine.ExecuteFile(@"C:\Users\Ubaid Qaiser\Desktop\tr.py");
                MessageBox.Show("Please wait while the time-table is being generated");
                Task t = Task.Delay(3000);
                t.Wait();

                MessageBox.Show("Time-Table generated successfully with no constraint violations");
                Task t1=Task.Delay(3000);
                t1.Wait();
                string fileExcel;
                fileExcel = @"C:\Users\Ubaid Qaiser\Downloads\Week4 Summer 2019.xlsx";
                Excel.Application xlapp;
                Excel.Workbook xlworkbook;
                xlapp = new Excel.Application();

                xlworkbook = xlapp.Workbooks.Open(fileExcel, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);

                xlapp.Visible = true;
            }

        }
        private void button_WOC3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button_WOC2_Click_1(object sender, EventArgs e)
        {
            originalForm.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void button_WOC5_Click(object sender, EventArgs e)
        {
            this.enable_button = true;
            
            if (enable_button == true && enable_button1 == true)
            {
                button_WOC1.Enabled = true;
                button_WOC1.ButtonColor = Color.RoyalBlue;
                button_WOC1.BorderColor = Color.RoyalBlue;
                button_WOC1.OnHoverButtonColor = Color.Aqua;
                button_WOC1.OnHoverBorderColor = Color.Aqua;
            }

        }

        private void pictureBox2_Click1(object sender, EventArgs e)
        {

        }

        private void button_WOC4_Click(object sender, EventArgs e)
        {
            this.enable_button1 = true;
            this.pictureBox4.Show();
            if (enable_button == true && enable_button1 == true)
            {
                button_WOC1.Enabled = true;
                button_WOC1.ButtonColor = Color.RoyalBlue;
                button_WOC1.BorderColor = Color.RoyalBlue;
                button_WOC1.OnHoverButtonColor = Color.Aqua;
                button_WOC1.OnHoverBorderColor = Color.Aqua;
            }


        }

        

        private void button_WOC5_Click_1(object sender, EventArgs e)
        {
            this.enable_button = true;
            this.pictureBox3.Show();
            if (enable_button == true && enable_button1 == true)
            {
                button_WOC1.Enabled = true;
                button_WOC1.ButtonColor = Color.RoyalBlue;
                button_WOC1.BorderColor = Color.RoyalBlue;
                button_WOC1.OnHoverButtonColor = Color.Aqua;
                button_WOC1.OnHoverBorderColor = Color.Aqua;
            }
        }

        private void button_WOC4_Click_1(object sender, EventArgs e)
        {
            this.enable_button1 = true;
            this.pictureBox4.Show();
            if (enable_button == true && enable_button1 == true)
            {
                button_WOC1.Enabled = true;
                button_WOC1.ButtonColor = Color.RoyalBlue;
                button_WOC1.BorderColor = Color.RoyalBlue;
                button_WOC1.OnHoverButtonColor = Color.Aqua;
                button_WOC1.OnHoverBorderColor = Color.Aqua;
            }
        }

        private void button_WOC1_Click_1(object sender, EventArgs e)
        {
            if (button_WOC1.Enabled == true)
            {

                MessageBox.Show("Please wait while the time-table is being generated");
                Task t = Task.Delay(3000);
                t.Wait();
                //                ScriptEngine engine = Python.CreateEngine();
                //                engine.ExecuteFile(@"C:\Users\Ubaid Qaiser\Desktop\GA+DB2.py");


                //                Microsoft.Scripting.Hosting.ScriptEngine pythonEngine =
                //                IronPython.Hosting.Python.CreateEngine();
                //               // We execute this script from Visual Studio 
                //                // so the program will be executed from bin\Debug or bin\Release
                //                Microsoft.Scripting.Hosting.ScriptSource pythonScript = pythonEngine.CreateScriptSourceFromFile(@"C:\Users\Ubaid Qaiser\Desktop\GA+DB2.py");
                //                pythonScript.Execute();

                var ipy = Python.CreateRuntime();
                dynamic test = ipy.UseFile(@"C:\Users\Ubaid Qaiser\Desktop\GA+DB2.py");
                test.Simple();
                Console.ReadKey();




                MessageBox.Show("Time-Table generated successfully with no constraint violations");
                Task t1 = Task.Delay(3000);
                t1.Wait();
                string fileExcel;
                fileExcel = @"C:\Users\Ubaid Qaiser\Downloads\Week4 Summer 2019.xlsx";
                Excel.Application xlapp;
                Excel.Workbook xlworkbook;
                xlapp = new Excel.Application();

            //    xlworkbook = xlapp.Workbooks.Open(fileExcel, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);

                xlapp.Visible = true;
            }
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showHome();
            hideYourProfile();
            hideRooms();
            hideCourses();
            hideTeachers();
        }

        private void updateProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hideHome();
            showYourProfile();
            hideRooms();
            hideCourses();
            hideTeachers();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void hideHome()
        {
            button_WOC1.Hide();
            button_WOC4.Hide();
            button_WOC5.Hide();
            pictureBox3.Hide();
            pictureBox4.Hide();
        }
        private void showHome()
        {
            button_WOC1.Show();
            button_WOC2.Show();
            button_WOC3.Show();
            button_WOC4.Show();
            button_WOC5.Show();
            if (enable_button1==true)
            {
                this.pictureBox4.Show();
            }
            if (enable_button == true)
            {
                this.pictureBox3.Show();
            }
            if (enable_button == true && enable_button1 == true)
            {
                button_WOC1.Enabled = true;
                button_WOC1.ButtonColor = Color.RoyalBlue;
                button_WOC1.BorderColor = Color.RoyalBlue;
                button_WOC1.OnHoverButtonColor = Color.Aqua;
                button_WOC1.OnHoverBorderColor = Color.Aqua;
            }
            this.dataGridView1.Hide();
        }

        private void showYourProfile()
        {
            pictureBox5.Show();
            pictureBox6.Show();
            textBox1.Show();
            textBox2.Show();
            textBox3.Show();
            buttonSubmit.Show();
            this.dataGridView1.Hide();
        }
        private void hideYourProfile()
        {
            pictureBox5.Hide();
            pictureBox6.Hide();
            textBox1.Hide();
            textBox2.Hide();
            textBox3.Hide();
            buttonSubmit.Hide();
        }

        private void manageUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hideHome();
            hideTeachers();
            hideCourses();
            hideRooms();
            showYourProfile();
            this.dataGridView1.Hide();
        }

        private void updateCoursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hideTeachers();
            hideHome();
            hideRooms();
            hideYourProfile();
            showCourses();
            this.dataGridView1.Hide();
            FillCombobox2();
            
        }

        private void updateTeachersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hideHome();
            hideCourses();
            hideRooms();
            hideYourProfile();
            showTeachers();
            this.dataGridView1.Hide();
 //           FillCombobox1();
            fillCourses();

            

        }
        


        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            this.originalForm.username = textBox1.Text;
            this.originalForm.password = textBox2.Text;
            MessageBox.Show("Password and username updated successfully");
        }
        private void hideRooms()
        {
            this.textBox4.Hide();
            this.comboBox1.Hide();
            this.AddRoom.Hide();
            this.Remove.Hide();
            this.ViewRooms.Hide();
            this.classLab.Hide();
        }
        private void showRooms()
        {
            this.textBox4.Show();
            this.comboBox1.Show();
            this.AddRoom.Show();
            this.Remove.Show();
            this.ViewRooms.Show();
            this.classLab.Show();
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private void updateRoomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hideYourProfile();
            hideHome();
            showRooms();
            hideCourses();
            hideTeachers();
            this.dataGridView1.Hide();
            FillCombobox();
        }
        private void hideCourses()
        {
            this.Section.Hide();
            this.courseName.Hide();
//            this.sectionsnumericUpDown1.Hide();
            this.comboBox2.Hide();
//            this.courseCode.Hide();
            this.AddCourse.Hide();
//            this.coursecomboBox2.Hide();
 //           this.courseName2.Hide();
 //           this.sectionsnumericUpDown2.Hide();
 //           this.coursecomboBox2.Hide();
            this.RemoveCourse.Hide();
 //           this.updateCourse.Hide();
            this.AddCourse.Hide();
            this.ViewCourses.Hide();

            this.RemoveCourse.Hide();
            this.ViewCourses.Hide();
 //           this.Day.Hide();
            this.coreElective.Hide();
 //           this.Timing.Hide();
        }
        private void showCourses()
        {
            this.Section.Show();
            this.courseName.Show();
//            this.sectionsnumericUpDown1.Show();
//            this.courseCode.Show();
            this.comboBox2.Show();
            this.AddCourse.Show();
//            this.coursecomboBox2.Show();
//            this.courseName2.Show();
//            this.sectionsnumericUpDown2.Show();
//            this.coursecomboBox2.Show();
            this.RemoveCourse.Show();
//            this.updateCourse.Show();
            this.AddCourse.Show();
            this.ViewCourses.Show();
//            this.Day.Show();
            this.coreElective.Show();
//            this.Timing.Show();
            this.RemoveCourse.Show();
            this.ViewCourses.Show();
            this.dataGridView1.Hide();
        }
        private void hideTeachers()
        {
            this.teacherName.Hide();
            this.teacherID.Hide();
            this.coursebox3.Hide();
            this.coursecomboBox4.Hide();
            this.coursecomboBox5.Hide();
 //           this.coursecomboBox6.Hide();
 //           this.coursecomboBox7.Hide();
 //           this.coursecomboBox8.Hide();
//            this.sectionsnumericUpDown3.Hide();
//            this.sectionnumericUpDown4.Hide();
//            this.sectionnumericUpDown5.Hide();
//            this.sectionnumericUpDown6.Hide();
//            this.sectionnumericUpDown7.Hide();
 //           this.sectionnumericUpDown8.Hide();
//            this.teachercombobox1.Hide();
//            this.TeachercomboBox2.Hide();
            this.AddTeacher.Hide();
//            this.updateTeacher.Hide();
            this.RemoveTeacher.Hide();
            this.ViewTeachers.Hide();
            this.P1C1.Hide();
            this.P1C2.Hide();
            this.P1C3.Hide();
            this.P2C1.Hide();
            this.P2C2.Hide();
            this.P2C3.Hide();
            this.P3C1.Hide();
            this.P3C2.Hide();
            this.P3C3.Hide();
        }
        private void showTeachers()
        {
            this.teacherName.Show();
            this.teacherID.Show();
            this.coursebox3.Show();
            this.coursecomboBox4.Show();
            this.coursecomboBox5.Show();
//            this.coursecomboBox6.Show();
//            this.coursecomboBox7.Show();
//            this.coursecomboBox8.Show();
//            this.sectionsnumericUpDown3.Show();
//            this.sectionnumericUpDown4.Show();
//            this.sectionnumericUpDown5.Show();
//            this.sectionnumericUpDown6.Show();
//            this.sectionnumericUpDown7.Show();
//            this.sectionnumericUpDown8.Show();
 //           this.teachercombobox1.Show();
//            this.TeachercomboBox2.Show();
            this.AddTeacher.Show();
//            this.updateTeacher.Show();
            this.RemoveTeacher.Show();
            this.ViewTeachers.Show();
            this.dataGridView1.Hide();
            this.P1C1.Show();
            this.P1C2.Show();
            this.P1C3.Show();
            this.P2C1.Show();
            this.P2C2.Show();
            this.P2C3.Show();
            this.P3C1.Show();
            this.P3C2.Show();
            this.P3C3.Show();
        }

        private static readonly Regex _regex = new Regex("[^0-9]+"); //regex that matches disallowed text
        

        private void AddRoom_Click(object sender, EventArgs e)
        {
            bool IsTextAllowed(string text)
            {
                return !_regex.IsMatch(text);
            }
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string s = textBox4.Text;
            string Check = classLab.SelectedItem.ToString();
            var textBox = sender as TextBox;
            if (Check == "Lab")
            {
                string CommandText = "Insert into room values('" + s + "','Lab',50)";
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                sqlcon.Close();
            }
            else if (Check == "Class" && IsTextAllowed(textBox4.Text)==true)
            {
                string CommandText = "Insert into room values('" +"C"+ s + "','Classroom', 50)";
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                sqlcon.Close();
            }

        }



        private void sectionnumericUpDown7_ValueChanged(object sender, EventArgs e)
        {

        }

        public void ViewRooms_Click(object sender, EventArgs e)
        {

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select * from room";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            dataGridView1.DataSource = DT;
            sqlcon.Close();
            this.dataGridView1.Show();

        }

        private void ViewTeachers_Click(object sender, EventArgs e)
        {

            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select InstructorID, Name from instructor";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            dataGridView1.DataSource = DT;
            sqlcon.Close();
            this.dataGridView1.Show();

            //dbobject.CloseConnection();
        }

        private void ViewCourses_Click(object sender, EventArgs e)
        {
            FillCombobox2();
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select CourseID, CourseName, CourseType, Tpreference,Qpreference,Dpreference from course";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            dataGridView1.DataSource = DT;
            sqlcon.Close();
            this.dataGridView1.Show();


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*                       SetConnection();
                                   sqlcon.Open();
                                   sqlcmd = sqlcon.CreateCommand();
                                   string CommandText = "select RNumber from room";
                                   DB = new SQLiteDataAdapter(CommandText, sqlcon);
                                   DS.Reset();
                                   DB.Fill(DS);
                                   DT = DS.Tables[0];
                                   comboBox1.DataSource = DT;
                                   comboBox1.ValueMember = "RNumber";
                                   comboBox1.DisplayMember = "RNumber";
                       comboBox1.DataBindings;
           */
        /*    SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string CommandText = "select RNumber from room";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            string cs = @"URI=file:C:\Users\Ubaid Qaiser\Desktop\FAST Access\FAST Access\FAST Access\bin\Debug\class_schedule_4.db";

            var con = new SQLiteConnection(cs);
            con.Open();

            string stm = "SELECT RNumber FROM room";

            var cmd = new SQLiteCommand(stm, con);
            SQLiteDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                string rNum = rdr.GetString(1);
        //        comboBox1.ItemsSource = DS.Tables[0].DefaultView;
            }
         /*   DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables["room"];
            while (myReader.Read())
            {

            }
            this.comboBox1.DisplayMember = "RNumber";
            this.comboBox1.ValueMember = "RNumber"; //Field in the datatable which you want to be the value of the combobox 
            this.comboBox1.DataSource = DS.Tables["room"];

    
            sqlcon.Close();

            //            this.dataGridView1.Show();*/
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string s = comboBox1.Text;
            string CommandText = "delete from room WHERE RNumber='"+ s +"'";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            sqlcon.Close();
            ViewRooms_Click(sender, e);
            FillCombobox();

        }

        private void RemoveCourse_Click(object sender, EventArgs e)
        {
            FillCombobox2();
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string s = comboBox2.Text;
            string CommandText = "delete from course WHERE CourseName='" + s + "'";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            sqlcon.Close();
            ViewCourses_Click(sender, e);
 //           FillCombobox1();
        }

        private void RemoveTeacher_Click(object sender, EventArgs e)
        {
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string s = teacherID.Text;
            string CommandText = "delete from instructor WHERE Name='" + s + "'";
            DB = new SQLiteDataAdapter(CommandText, sqlcon);
            DS.Reset();
            DB.Fill(DS);
            sqlcon.Close();
            ViewTeachers_Click(sender, e);
            FillCombobox1();
        }

        private void teacherID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void coursebox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void classLab_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Check = classLab.SelectedItem.ToString();
            if (Check == "Lab")
            {
                textBox4.Enabled = true;
                textBox4.BackColor = Color.WhiteSmoke;
            }
            else
            {

                textBox4.Enabled = true;
                textBox4.BackColor = Color.WhiteSmoke;
            }
        }

        private void AddCourse_Click(object sender, EventArgs e)
        {
            bool IsTextAllowed(string text)
            {
                return !_regex.IsMatch(text);
            }
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string s = courseName.Text;
            string sec = Section.Text;
            string Check = coreElective.SelectedItem.ToString();
            var textBox = sender as TextBox;
            if (Check == "Core" && IsTextAllowed(courseName.Text) == false &&sec != "Section")
            {
                string CommandText = "Insert into course(coursename,coursetype,section,maxnumofstudents,tpreference,dpreference,qpreference) values('" + s + "','Core','"+sec+"',45,0,0,0)";
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                /*string CommandText2 = "select courseid from course where coursename = '" + s + "' ";
                DB3 = new SQLiteDataAdapter(CommandText2, sqlcon);
                DS3.Reset();
                DB3.Fill(DS3);
                DT = DS3.Tables[0];
                Console.WriteLine("Heloooo", DS3);
                int l = DS3;
                string CommandText1 = string.Format("Insert into course_instructor (course_number) values ({0})", l);
                DB1 = new SQLiteDataAdapter(CommandText1, sqlcon);
                DS1.Reset();
                DB1.Fill(DS1);*/
                sqlcon.Close();
            }
            else if (Check == "Elective" && IsTextAllowed(courseName.Text) == false && sec != "Section")
            {
                string CommandText = "Insert into course(coursename,coursetype,section,maxnumofstudents,tpreference,dpreference,qpreference) values('" + s + "','Elective','" + sec + "',45,0,0,0)";
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                sqlcon.Close();
            }
            else if (Check == " Elective Lab " && IsTextAllowed(courseName.Text) == false && sec != "Section")
            {
                string CommandText = "Insert into course(coursename,coursetype,section,maxnumofstudents,tpreference,dpreference,qpreference) values('" + s + "','Elective Lab','" + sec + "',45,0,0,0)";
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                sqlcon.Close();
            }
            else if (Check == "Core Lab" && IsTextAllowed(courseName.Text) == false && sec != "Section")
            {
                string CommandText = "Insert into course(coursename,coursetype,section,maxnumofstudents,tpreference,dpreference,qpreference) values('" + s + "','Core Lab','" + sec + "',45,0,0,0)";
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                sqlcon.Close();
            }

        }

        private void Section_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AddTeacher_Click(object sender, EventArgs e)
        {
            bool IsTextAllowed(string text)
            {
                return !_regex.IsMatch(text);
            }
            SetConnection();
            sqlcon.Open();
            sqlcmd = sqlcon.CreateCommand();
            string s = teacherName.Text;
//            string Check = coreElective.SelectedItem.ToString();
            var textBox = sender as TextBox;
            string c1 = coursebox3.Text;
            string c2 = coursecomboBox4.Text;
            string c3 = coursecomboBox5.Text;
            string d1 = P1C1.Text;
            string d2 = P1C2.Text;
            string d3 = P1C3.Text;
            string t1 = P2C1.Text;
            string t2 = P2C2.Text;
            string t3 = P2C3.Text;
            string day1 = P1C3.Text;
            string day2 = P2C3.Text;
            string day3 = P3C3.Text;
            string dd1,dd2,dd3;
            int dd11;
            int dd22;
            int dd33;
            double qq11;
            double qq22;
            double qq33;
            int tt11;
            int tt22;
            int tt33;


            if (IsTextAllowed(teacherName.Text) == false)
            {

                string CommandText2 = "Insert into instructor(name,spacer,spacercheck) values('" + s + "',0,0)";
                DB2 = new SQLiteDataAdapter(CommandText2, sqlcon);
                DS2.Reset();
                DB2.Fill(DS2);
                /*string CommandText2 = "select instructorid from instructor where name = '" + s + "' ";
                DB3 = new SQLiteDataAdapter(CommandText2, sqlcon);
                DS3.Reset();
                DB3.Fill(DS3);
                DT = DS3.Tables[0];
                Console.WriteLine("Heloooo", DS3);
                int l = DS3;
                string CommandText1 = string.Format("Insert into course_instructor (instructor_number) values ({0})", l);
                DB1 = new SQLiteDataAdapter(CommandText1, sqlcon);
                DS1.Reset();
                DB1.Fill(DS1);*/
                if (P1C1.Text == "3hr x 1 class")
                {
                    
                    qq11 = 3;
                    dd1 = P3C1.Text;
                    if (dd1 == "Monday")
                    {
                        dd11 = 1;
                    }
                    else if (dd1 == "Tuesday")
                    {
                        dd11 = 2;
                    }
                    else if (dd1 == "Wednesday")
                    {
                        dd11 = 3;
                    }
                    else if (dd1 == "Thursday")
                    {
                        dd11 = 4;
                    }
                    else
                    {
                        dd11 = 5;
                    }

                }
                else if (P1C1.Text == "2hr x 1 class")
                {
                    
                    qq11 = 2;
                    dd1 = P3C1.Text;
                    if (dd1 == "Monday")
                    {
                        dd11 = 1;
                    }
                    else if (dd1 == "Tuesday")
                    {
                        dd11 = 2;
                    }
                    else if (dd1 == "Wednesday")
                    {
                        dd11 = 3;
                    }
                    else if (dd1 == "Thursday")
                    {
                        dd11 = 4;
                    }
                    else
                    {
                        dd11 = 5;
                    }

                }
                else if (P1C1.Text == "1.5hr x 2 class")
                {
                    qq11 = 1.5;
                    dd1 = P3C1.Text;
                    if (dd1 == "Monday,Tuesday")
                    {
                        dd11 = 1;
                    }
                    else if (dd1 == "Tuesday,Wednesday")
                    {
                        dd11 = 2;
                    }
                    else if (dd1 == "Tuesday,Thursday")
                    {
                        dd11 = 3;
                    }
                    else if (dd1 == "Monday,Friday")
                    {
                        dd11 = 4;
                    }
                    else
                    {
                        dd11 = 5;
                    }

                }
                else 
                {
                    qq11 = 1;
                    dd1 = P3C1.Text;
                    if (dd1 == "Monday,Wednesday,Friday")
                    {
                        dd11 = 1;
                    }
                    else if (dd1 == "Tuesday,Wednesday,Thursday")
                    {
                        dd11 = 2;
                    }
                    else if (dd1 == "Wednesday,Thursday,Friday")
                    {
                        dd11 = 3;
                    }
                    else if (dd1 == "Tuesday,Thursday,Friday")
                    {
                        dd11 = 4;
                    }
                    else
                    {
                        dd11 = 5;
                    }

                }


                if (P1C2.Text == "3hr x 1 class")
                {
                    qq22 = 3;
                    dd1 = P3C2.Text;
                    if (dd1 == "Monday")
                    {
                        dd22 = 1;
                    }
                    else if (dd1 == "Tuesday")
                    {
                        dd22 = 2;
                    }
                    else if (dd1 == "Wednesday")
                    {
                        dd22 = 3;
                    }
                    else if (dd1 == "Thursday")
                    {
                        dd22 = 4;
                    }
                    else
                    {
                        dd22 = 5;
                    }

                }
                else if (P1C2.Text == "2hr x 1 class")
                {
                    qq22 = 2;
                    dd1 = P3C2.Text;
                    if (dd1 == "Monday")
                    {
                        dd22 = 1;
                    }
                    else if (dd1 == "Tuesday")
                    {
                        dd22 = 2;
                    }
                    else if (dd1 == "Wednesday")
                    {
                        dd22 = 3;
                    }
                    else if (dd1 == "Thursday")
                    {
                        dd22 = 4;
                    }
                    else
                    {
                        dd22 = 5;
                    }

                }
                else if (P1C2.Text == "1.5hr x 2 class")
                {
                    qq22 = 1.5;
                    dd1 = P3C2.Text;
                    if (dd1 == "Monday,Tuesday")
                    {
                        dd22 = 1;
                    }
                    else if (dd1 == "Tuesday,Wednesday")
                    {
                        dd22 = 2;
                    }
                    else if (dd1 == "Tuesday,Thursday")
                    {
                        dd22 = 3;
                    }
                    else if (dd1 == "Monday,Friday")
                    {
                        dd22 = 4;
                    }
                    else
                    {
                        dd22 = 5;
                    }

                }
                else 
                {
                    qq22 = 1;
                    dd1 = P3C2.Text;
                    if (dd1 == "Monday,Wednesday,Friday")
                    {
                        dd22 = 1;
                    }
                    else if (dd1 == "Tuesday,Wednesday,Thursday")
                    {
                        dd22 = 2;
                    }
                    else if (dd1 == "Wednesday,Thursday,Friday")
                    {
                        dd22 = 3;
                    }
                    else if (dd1 == "Tuesday,Thursday,Friday")
                    {
                        dd22 = 4;
                    }
                    else
                    {
                        dd22 = 5;
                    }

                }



                if (P1C3.Text == "3hr x 1 class")
                {
                    qq33 = 3;
                    dd1 = P3C3.Text;
                    if (dd1 == "Monday")
                    {
                        dd33 = 1;
                    }
                    else if (dd1 == "Tuesday")
                    {
                        dd33 = 2;
                    }
                    else if (dd1 == "Wednesday")
                    {
                        dd33 = 3;
                    }
                    else if (dd1 == "Thursday")
                    {
                        dd33 = 4;
                    }
                    else
                    {
                        dd33 = 5;
                    }

                }
                else if (P1C3.Text == "2hr x 1 class")
                {
                    qq33 = 2;
                    dd1 = P3C3.Text;
                    if (dd1 == "Monday")
                    {
                        dd33 = 1;
                    }
                    else if (dd1 == "Tuesday")
                    {
                        dd33 = 2;
                    }
                    else if (dd1 == "Wednesday")
                    {
                        dd33 = 3;
                    }
                    else if (dd1 == "Thursday")
                    {
                        dd33 = 4;
                    }
                    else
                    {
                        dd33 = 5;
                    }

                }
                else if (P1C3.Text == "1.5hr x 2 class")
                {
                    qq33 = 1.5;
                    dd1 = P3C3.Text;
                    if (dd1 == "Monday,Tuesday")
                    {
                        dd33 = 1;
                    }
                    else if (dd1 == "Tuesday,Wednesday")
                    {
                        dd33 = 2;
                    }
                    else if (dd1 == "Tuesday,Thursday")
                    {
                        dd33 = 3;
                    }
                    else if (dd1 == "Monday,Friday")
                    {
                        dd33 = 4;
                    }
                    else
                    {
                        dd33 = 5;
                    }

                }
                else 
                {
                    qq33 = 1;
                    dd1 = P3C3.Text;
                    if (dd1 == "Monday,Wednesday,Friday")
                    {
                        dd33 = 1;
                    }
                    else if (dd1 == "Tuesday,Wednesday,Thursday")
                    {
                        dd33 = 2;
                    }
                    else if (dd1 == "Wednesday,Thursday,Friday")
                    {
                        dd33 = 3;
                    }
                    else if (dd1 == "Tuesday,Thursday,Friday")
                    {
                        dd33 = 4;
                    }
                    else
                    {
                        dd33 = 5;
                    }

                }

                if(P2C1.Text=="First Half")
                {
                    tt11 = 1;
                }
                else 
                {
                    tt11 = 2;
                }

                if (P2C2.Text == "First Half")
                {
                    tt22 = 1;
                }
                else
                {
                    tt22 = 2;
                }

                if (P2C3.Text == "First Half")
                {
                    tt33 = 1;
                }
                else 
                {
                    tt33 = 2;
                }

                
                string CommandText = string.Format("Update course set Tpreference = {0} , Dpreference = {1} ,Qpreference = {2} where coursename =  '" + c1 + "'",qq11,dd11,tt11);
                string CommandText1 = string.Format("Update course set Tpreference = {0} , Dpreference = {1} ,Qpreference = {2} where coursename =  '" + c2 + "'", qq22, dd22, tt22);
                string CommandText3 = string.Format("Update course set Tpreference = {0} , Dpreference = {1} ,Qpreference = {2} where coursename =  '" + c2 + "'", qq33, dd33, tt33);
                
                DB = new SQLiteDataAdapter(CommandText, sqlcon);
                DS.Reset();
                DB.Fill(DS);
                DB1 = new SQLiteDataAdapter(CommandText1, sqlcon);
                DS1.Reset();
                DB1.Fill(DS1);
                DB3 = new SQLiteDataAdapter(CommandText3, sqlcon);
                DS3.Reset();
                DB3.Fill(DS3);

                sqlcon.Close();
            }
            else
            {
                //Display invalid name message
            }


        }

        private void P1C1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (P1C1.Text == "Duration")
            {
                //3x1
                this.P3C1.Items.Clear();
                this.P3C1.Enabled = false;
                this.P3C1.BackColor = Color.DarkGray;
            }
            if (P1C1.Text== "3hr x 1 class")
            {
                
                //3x1
                this.P3C1.Enabled = true;
                this.P3C1.BackColor = Color.WhiteSmoke;
                this.P3C1.Items.Clear();
                this.P3C1.Items.Add("Monday");
                this.P3C1.Items.Add("Tuesday");
                this.P3C1.Items.Add("Wednesday");
                this.P3C1.Items.Add("Thursday");
                this.P3C1.Items.Add("Friday");
            }
            else if(P1C1.Text == "2hr x 1 class")
            {
                
                this.P3C1.Enabled = true;
                this.P3C1.BackColor = Color.WhiteSmoke;
                this.P3C1.Items.Clear();
                this.P3C1.Items.Add("Monday");
                this.P3C1.Items.Add("Tuesday");
                this.P3C1.Items.Add("Wednesday");
                this.P3C1.Items.Add("Thursday");
                this.P3C1.Items.Add("Friday");
            }
            else if (P1C1.Text == "1.5hr x 2 class")
            {
                Console.WriteLine("1.5hr x 1 class");
                this.P3C1.Enabled = true;
                this.P3C1.BackColor = Color.WhiteSmoke;
                this.P3C1.Items.Clear();
                //1.5x2
                this.P3C1.Items.Add("Monday,Tuesday");//1
                this.P3C1.Items.Add("Wednesday,Thursday");//5
                this.P3C1.Items.Add("Tuesday,Wednesday");//2
                this.P3C1.Items.Add("Monday,Friday");//4
                this.P3C1.Items.Add("Tuesday,Thursday");//3
            }
            else if (P1C1.Text == "1hr x 3 class")
            {
                Console.WriteLine("1hr x 1 class");
                this.P3C1.Enabled = true;
                this.P3C1.BackColor = Color.WhiteSmoke;
                this.P3C1.Items.Clear();
                //1hourx3
                this.P3C1.Items.Add("Monday,Wednesday,Friday");//1
                this.P3C1.Items.Add("Monday,Thursday,Friday");//5
                this.P3C1.Items.Add("Tuesday,Wednesday,Thursday");//2
                this.P3C1.Items.Add("Wednesday,Thursday,Friday");//3
                this.P3C1.Items.Add("Tuesday,Thursday,Friday");//4
            }
            
        }

        private void P1C2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (P1C2.Text == "Duration")
            {
                //3x1
                this.P3C2.Items.Clear();
                this.P3C2.Enabled = false;
                this.P3C2.BackColor = Color.DarkGray;
            }
            if (P1C2.Text == "3hr x 1 class")
            {
                //3x1
                this.P3C2.Enabled = true;
                this.P3C2.BackColor = Color.WhiteSmoke;
                this.P3C2.Items.Clear();
                this.P3C2.Items.Add("Monday");
                this.P3C2.Items.Add("Tuesday");
                this.P3C2.Items.Add("Wednesday");
                this.P3C2.Items.Add("Thursday");
                this.P3C2.Items.Add("Friday");
            }
            else if (P1C2.Text == "2hr x 1 class")
            {
                //3x1
                this.P3C2.Enabled = true;
                this.P3C2.BackColor = Color.WhiteSmoke;
                this.P3C2.Items.Clear();
                this.P3C2.Items.Add("Monday");
                this.P3C2.Items.Add("Tuesday");
                this.P3C2.Items.Add("Wednesday");
                this.P3C2.Items.Add("Thursday");
                this.P3C2.Items.Add("Friday");
            }
            else if (P1C2.Text == "1.5hr x 2 class")
            {
                //3x1
                this.P3C2.Enabled = true;
                this.P3C2.BackColor = Color.WhiteSmoke;
                this.P3C2.Items.Clear();

                //1.5x2
                this.P3C2.Items.Add("Monday,Tuesday");//1
                this.P3C2.Items.Add("Wednesday,Thursday");//5
                this.P3C2.Items.Add("Tuesday,Wednesday");//2
                this.P3C2.Items.Add("Monday,Friday");//4
                this.P3C2.Items.Add("Tuesday,Thursday");//3
            }
            else if (P1C2.Text == "1hr x 3 class")
            {
                //3x1
                this.P3C2.Enabled = true;
                this.P3C2.BackColor = Color.WhiteSmoke;
                this.P3C2.Items.Clear();
                //1hourx3
                this.P3C2.Items.Add("Monday,Wednesday,Friday");//1
                this.P3C2.Items.Add("Monday,Thursday,Friday");//5
                this.P3C2.Items.Add("Tuesday,Wednesday,Thursday");//2
                this.P3C2.Items.Add("Wednesday,Thursday,Friday");//3
                this.P3C2.Items.Add("Tuesday,Thursday,Friday");//4
            }

        }

        private void P1C3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (P1C3.Text == "Duration")
            {
                //3x1
                this.P3C3.Items.Clear();
                this.P3C3.Enabled = false;
                this.P3C3.BackColor = Color.DarkGray;
            }
            if (P1C3.Text == "3hr x 1 class")
            {
                //3x1
                this.P3C3.Enabled = true;
                this.P3C3.BackColor = Color.WhiteSmoke;
                this.P3C3.Items.Clear();
                this.P3C3.Items.Add("Monday");
                this.P3C3.Items.Add("Tuesday");
                this.P3C3.Items.Add("Wednesday");
                this.P3C3.Items.Add("Thursday");
                this.P3C3.Items.Add("Friday");
            }
            else if (P1C3.Text == "2hr x 1 class")
            {
                //3x1
                this.P3C3.Enabled = true;
                this.P3C3.BackColor = Color.WhiteSmoke;
                this.P3C3.Items.Clear();
                this.P3C3.Items.Add("Monday");
                this.P3C3.Items.Add("Tuesday");
                this.P3C3.Items.Add("Wednesday");
                this.P3C3.Items.Add("Thursday");
                this.P3C3.Items.Add("Friday");
            }
            else if (P1C3.Text == "1.5hr x 2 class")
            {
                this.P3C3.Enabled = true;
                this.P3C3.BackColor = Color.WhiteSmoke;
                //3x1
                this.P3C3.Items.Clear();

                //1.5x2
                this.P3C3.Items.Add("Monday,Tuesday");//1
                this.P3C3.Items.Add("Wednesday,Thursday");//5
                this.P3C3.Items.Add("Tuesday,Wednesday");//2
                this.P3C3.Items.Add("Monday,Friday");//4
                this.P3C3.Items.Add("Tuesday,Thursday");//3
            }
            else if (P1C3.Text == "1hr x 3 class")
            {
                this.P3C3.Enabled = true;
                this.P3C3.BackColor = Color.WhiteSmoke;
                //3x1
                this.P3C3.Items.Clear();
                //1hourx3
                this.P3C3.Items.Add("Monday,Wednesday,Friday");//1
                this.P3C3.Items.Add("Monday,Thursday,Friday");//5
                this.P3C3.Items.Add("Tuesday,Wednesday,Thursday");//2
                this.P3C3.Items.Add("Wednesday,Thursday,Friday");//3
                this.P3C3.Items.Add("Tuesday,Thursday,Friday");//4
            }
        }
    }
}
